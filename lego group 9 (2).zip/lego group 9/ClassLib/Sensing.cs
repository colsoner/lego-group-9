using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Lego.Ev3.Core;
using Lego.Ev3.Desktop;
using System.Threading.Tasks;

namespace LegoStormGrp9
{

    public class Sensing
    {
        public int pColour;
        public double pDist;
        public int pGyro;

        public Brick Brick;

        public Sensing(Brick _Brick)
        {
            Brick = _Brick;

            Brick.BrickChanged += GetClr;
            Brick.BrickChanged += GetDist;
            Brick.BrickChanged += GetGyro;
        }

        ~Sensing()
        {

        }

        //public void BrickChanged(object sender, BrickChangedEventArgs e)
        //{
        //    Brick.BrickChanged += GetClr;
        //    Brick.BrickChanged += GetDist;
        //    Brick.BrickChanged += GetGyro;
        //    //pColour = e.Ports[InputPort.Three].SIValue.ToString();
        //    //pDist = e.Ports[InputPort.Two].SIValue.ToString();
        //    //pGyro = e.Ports[InputPort.One].SIValue.ToString();
        //}

        void GetClr(object sender, BrickChangedEventArgs e)
        {
           pColour = (int)e.Ports[InputPort.Three].SIValue;
        }

        void GetDist(object sender, BrickChangedEventArgs e)
        {              
            pDist = (double)e.Ports[InputPort.Two].SIValue;
        }

        void GetGyro(object sender, BrickChangedEventArgs e)
        {
            pGyro = (int)e.Ports[InputPort.One].SIValue;
        }

    }

    //end Sensing
}
