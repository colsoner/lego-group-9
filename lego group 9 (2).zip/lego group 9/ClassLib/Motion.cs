using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Lego.Ev3.Core;
using Lego.Ev3.Desktop;

namespace LegoStormGrp9
{
    public class Motion
    {
        public Brick pBrick;
        public Sensing pSensing;
        public Motion(Brick _brick, Sensing _Sense)
        {
            pBrick = _brick;
            pSensing = _Sense;
        }

        ~Motion()
        {

        }

        /// 
        /// <param name="pPower1"></param>
        /// <param name="pPower2"></param>
        /// <param name="pTime"></param>
        /// <param name="pBrake"></param>
        public async void Move(int pPower1, int pPower2, uint pTime, bool pBrake)
        {

            //brick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.A, pPower1, pTime, pBrake | OutputPort.B, pPower2, pTime, false);    <--- code Lachie was talking about where we use both motors.

            pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.A, pPower1, pTime, pBrake);
            pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.D, pPower2, pTime, pBrake);
            await pBrick.BatchCommand.SendCommandAsync();
        }

        /// <summary>
        /// pGyroTurn = how much to turn
        /// </summary>
        /// <param name="pGyroTurn"></param>
        public async void Rotate(int pGyroTurn)
        {
            int vGyroStart = Convert.ToInt32(pSensing.pGyro);

            if (pGyroTurn > 0)
            {
                do
                {
                    pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.D, -30, 10000, false);
                    pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.A, 30, 10000, false);
                    await pBrick.BatchCommand.SendCommandAsync();
                } while (vGyroStart <= (vGyroStart + pGyroTurn));
            }
            else
            {
                do
                {
                    pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.D, 30, 10000, false);
                    pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.A, -30, 10000, false);
                    await pBrick.BatchCommand.SendCommandAsync();
                } while (vGyroStart >= (vGyroStart + pGyroTurn));
            }
        }
    }
}