using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Lego.Ev3.Core;
using Lego.Ev3.Desktop;

namespace LegoStormGrp9
{

    public class Arena
    {

        /// <summary>
        /// Contains Blue, Red, Black, Yellow {2 ,5 ,1 ,4 }
        /// </summary>
        public int[] HomeCnr;
        public int[] Colors = { 2, 5, 1, 4 };

        public Sensing pSensing;
        public Motion pMotion;
        public Brick pBrick;

        public Arena(Brick _Brick)
        {
            pBrick = _Brick;
        }

        /// <summary>
        /// Rotate 360 to determine the shortest distance.
        /// </summary>
        /// <param name="pGyro"></param>
        /// <param name="pDistance"></param>
        public int GetNearestWallColor(int pGyro, double pDistance)
        {

            return 0;
        }

        /// 
        /// <param name="pColorStart"></param>
        public int MovementLogic(int pColorStart)
        {
            
            int Left;
            var index = Array.IndexOf(Colors, pColorStart);

            switch (index)
            {
                case 0:
                    Left = 3;
                    break;

                default:
                    Left = index - 1;
                    break;
            }

            if (Colors[index] == HomeCnr[0] || Colors[index] == HomeCnr[1])
            {
                if (Colors[Left] == HomeCnr[0] || Colors[Left] == HomeCnr[1])
                {
                    return -90;
                }
                else
                {
                    return 90;
                }
            }
            else
            {
                return 180;
            }

        }

        public void AlignToWall()
        {
            pSensing = new Sensing(pBrick);             //declare local instances of Sensing and Motion classe
            pMotion = new Motion(pBrick,pSensing);

                                                        //    <=- Order of operations -=>

            double vDistShortest = pSensing.pDist;               // Variable for storing shortest distance
            int vGyroShortest = pSensing.pGyro;                  // Variable for storing store shortest gyro

            int vGyroStart = pSensing.pGyro;                         // 2. Store starting gyro for reallignment

            if (pSensing.pDist <= 2)                                         // 3. If distance <= 2cm move backwards for manuverability
            {
                pMotion.Move(-30, -30, 50, false);
            }

            pMotion.Rotate(360);                                    // 4. Do a 360* turn

            do                                                      // 5. Update vShortestDist+Gyro if vCurrentDist+Gyro is shorter
            {
                if (pSensing.pDist < vDistShortest)
                {
                    vDistShortest = pSensing.pDist;
                    vGyroShortest = pSensing.pGyro;
                }
            } while (pSensing.pGyro >= (vGyroStart + 360));       // until 360 turn is complete

            pMotion.Rotate(vGyroShortest - pSensing.pGyro);

            do                                                     // 6. Get within working colour sensor distance
            {
                //pMotion.Move(20, 20, 100, false);
                pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.A, 20, 100, false);
                pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.D, 20, 100, false);
            } while (pSensing.pDist > 1);

            //pMotion.Move(0, 0, 100, true);              // Break motors
            pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.A, 0, 0, true);
            pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.D, 0, 0, true);

            do                                              // 7. Reverse for turning space
            {
                //pMotion.Move(-10, -10, 100, false);
                pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.A, -10, 100, false);
                pBrick.BatchCommand.TurnMotorAtPowerForTime(OutputPort.D, -10, 100, false);
            } while (pSensing.pDist < 2);

            pMotion.Move(0, 0, 100, true);              // Break motors
        }
    }

    //end MyBrick
}