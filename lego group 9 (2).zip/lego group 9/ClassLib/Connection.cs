using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Lego.Ev3.Core;
using Lego.Ev3.Desktop;

namespace LegoStormGrp9
{

    public class Connection
    {

        public MyBrick m_MyBrick;

        public Connection()
        {

        }

        ~Connection()
        {

        }

        public int MakeConnection()
        {

            return 0;
        }

    }//end Connection
}